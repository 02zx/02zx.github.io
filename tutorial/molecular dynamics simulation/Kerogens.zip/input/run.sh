#!/bin/bash
#SBATCH -n 16
#SBATCH -J eq
#SBATCH -N 1
#SBATCH -p NVIDIAGeForceRTX3090
#SBATCH --gres=gpu:1
#SBATCH -e error.err1
#SBATCH -o output.out1

module load apps/anaconda3/2021.05
module load compiler/gcc/7.3.1
module load compiler/intel/2021.3.0
module load mpi/intelmpi/2021.3.0
module swap apps/gromacs/intelmpi/2021.7.gpu
module load mathlib/fftw/intelmpi/3.3.9_single
#gmx mdrun -ntmpi 1 -ntomp 16 -pin on -deffnm ./eq/eq -v -gpu_id 0 -pme gpu -nb gpu
gmx mdrun -ntmpi 1 -ntomp 16 -pin on -deffnm ./prod/md -v -gpu_id 0 -pme gpu -nb gpu
